param(
        [string]$DeviceName = "$env:COMPUTERNAME",
        [string]$LogFile    = "C:\Temp\SCCM_Client_Triggers.log",
        [string]$JsonFile   = "C:\Temp\SCCM_Client_Triggers.json",
        [string]$SiteCode   = "UNKNOWN",
        [string]$Collection = "UNKNOWN",
        [string]$LBU        = "UNKNOWN"
      )
      Start-Transcript -Path $LogFile -Force -Append | Out-Null
      Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force

      $results = @()
      $overallStatus = "Success"
      function Invoke-Trigger { param([string]$Guid,[string]$Name)
        $entry = [ordered]@{name=$Name; guid=$Guid; status="Unknown"; error=$null; time=(Get-Date).ToString("s")}
        try {
          Invoke-WmiMethod -Class SMS_Client -Namespace root/ccm -Name TriggerSchedule -ArgumentList $Guid -ErrorAction Stop | Out-Null
          $entry.status = "Success"
        } catch {
          $entry.status = "Failed"; $entry.error = $_.Exception.Message; $overallStatus = "Failed"
        }
        $results += $entry
      }
      $triggers = @(
        @{ guid = "{00000000-0000-0000-0000-000000000021}"; name = "Machine Policy Retrieval Cycle" },
        @{ guid = "{00000000-0000-0000-0000-000000000001}"; name = "Hardware Inventory" },
        @{ guid = "{00000000-0000-0000-0000-000000000002}"; name = "Software Inventory" },
        @{ guid = "{00000000-0000-0000-0000-000000000021}"; name = "Machine Policy Assignment Request" },
        @{ guid = "{00000000-0000-0000-0000-000000000022}"; name = "Machine Policy Evaluation" },
        @{ guid = "{00000000-0000-0000-0000-000000000108}"; name = "Software Update Deployment" },
        @{ guid = "{00000000-0000-0000-0000-000000000113}"; name = "Software Update Scan" },
        @{ guid = "{00000000-0000-0000-0000-000000000114}"; name = "Software Update Deployment Re-evaluation" },
        @{ guid = "{00000000-0000-0000-0000-000000000121}"; name = "Application Deployment Evaluation Cycle" },
        @{ guid = "{00000000-0000-0000-0000-000000000027}"; name = "User Policy Evaluation Cycle" }
      )
      foreach ($t in $triggers) { Invoke-Trigger -Guid $t.guid -Name $t.name }

      $summary = [ordered]@{
        device_name = $DeviceName; site_code=$SiteCode; collection=$Collection; lbu=$LBU;
        timestamp=(Get-Date).ToString("s"); overall=$overallStatus; results=$results
      }
      try { $summary | ConvertTo-Json -Depth 5 | Out-File -FilePath $JsonFile -Encoding UTF8 -Force } catch { $overallStatus = "Failed" }
      try { Stop-Transcript | Out-Null } catch {}
      if ($overallStatus -eq "Success") { exit 0 } else { exit 1 }
